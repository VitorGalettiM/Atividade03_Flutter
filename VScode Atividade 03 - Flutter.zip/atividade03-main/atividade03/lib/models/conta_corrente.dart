class ContaCorrente {
  final String numeroConta;
  ContaCorrente(this.numeroConta);

  @override
  String toString() => 'Conta Corrente ($numeroConta)';
}

class ContaPoupanca {
  final String numeroConta;
  ContaPoupanca(this.numeroConta);

  @override
  String toString() => 'Conta Poupança ($numeroConta)';
}
